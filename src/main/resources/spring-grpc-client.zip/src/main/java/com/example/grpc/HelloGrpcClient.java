package com.example.grpc;

import hello.HelloServiceGrpc;
import hello.HelloRequest;
import hello.HelloResponse;
import io.grpc.ManagedChannel;
import io.grpc.netty.shaded.io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.nio.file.Files;
import java.nio.file.Paths;

@Slf4j
@Service
public class HelloGrpcClient {

    @Value("classpath:cert/ca.crt")
    private Resource caCertFile;

    @Value("classpath:cert/client.crt")
    private Resource clientCertFile;

    @Value("classpath:cert/client.key")
    private Resource clientKeyFile;

    @Value("${grpc.client.hello-service.address}")
    private String address;

    private HelloServiceGrpc.HelloServiceBlockingStub helloStub;

    @PostConstruct
    public void init() {
        try {
            byte[] caCert = Files.readAllBytes(Paths.get(caCertFile.getURI()));
            byte[] clientCert = Files.readAllBytes(Paths.get(clientCertFile.getURI()));
            byte[] clientKey = Files.readAllBytes(Paths.get(clientKeyFile.getURI()));

            ManagedChannel channel = NettyChannelBuilder.forTarget(address)
                .sslContext(GrpcSslContexts.forClient()
                    .trustManager(caCert)
                    .keyManager(clientCert, clientKey)
                    .build())
                .build();

            helloStub = HelloServiceGrpc.newBlockingStub(channel);
            log.info("gRPC client initialized successfully.");
        } catch (Exception e) {
            throw new RuntimeException("Failed to configure gRPC TLS", e);
        }
    }

    public String sayHello(String name) {
        HelloRequest request = HelloRequest.newBuilder().setName(name).build();
        HelloResponse response = helloStub.sayHello(request);
        return response.getMessage();
    }
}